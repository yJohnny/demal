//
//  BackSound.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/22/20.
//

import SwiftUI
import FirebaseStorage

struct BackSound: View {
    @ObservedObject var soundView = BackSoundModel()
    @EnvironmentObject var settings: UserInfo
    @Binding var showBackSound: Bool
    @State var savedURL = ""
    @State var isPlaying = false
    @State var isPlayingOffline = false
    @Environment(\.presentationMode) var presentationMode
    
    let width = UIScreen.main.bounds.width
    let height = UIScreen.main.bounds.height
    
    var body: some View {
        ZStack {
            if settings.backgroundUrl == "background" {
                Image("background")
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            } else {
                Image(uiImage: UIImage(contentsOfFile: settings.getUrlPath(lastComponent: settings.backgroundUrl)) ?? UIImage())
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            }
            VStack() {
                // VOLUME SLIDER
                
                HStack {
                    Text(settings.kzLang ? "Дауыс мөлшері" :"Громкость звука").foregroundColor(.white).font(Font.headline.bold())
                    Spacer()
                    Image(systemName: soundView.currentVolume == 0 ? "speaker.slash.fill" : "speaker.wave.2.fill").resizable().frame(width: width/18.75, height: height/33.35).foregroundColor(soundView.currentVolume == 0 ? .demalRed : .white)
                    Slider(value: Binding(get: {soundView.currentVolume}, set: { newValue in
                        soundView.setVolume(vol: newValue)
                    }), in: 0...1.0).frame(width: width/2.5)
                }.padding(.horizontal).frame(width: width, height: height/9.5).background(Color.demalGreen).onTapGesture(perform: {
                    showBackSound = false
                    presentationMode.wrappedValue.dismiss()
                })
                
                // ALL BACKSOUNDS
                ScrollView(.vertical, showsIndicators: false) {
                    ForEach(soundView.allSounds) { sound in
                        VStack() {
                            Button(action: {
                                if !settings.checkExisting(urlString: sound.musicUrl) {
                                if savedURL != sound.musicUrl {
                                    soundView.playSong(url: sound.musicUrl)
                                    savedURL = sound.musicUrl
                                    isPlaying = true
                                    isPlayingOffline = false
                                } else {
                                    if isPlaying {
                                        soundView.pauseSong()
                                        isPlaying = false
                                    } else {
                                        soundView.continueSong()
                                        isPlaying = true
                                    }
                                }
                                } else {
                                    if savedURL != sound.musicUrl {
                                        soundView.playFromDocuments(url: soundView.getMusicPath(urlString: sound.musicUrl))
                                        savedURL = sound.musicUrl
                                        isPlayingOffline = true
                                        isPlaying = false
                                    } else {
                                        if isPlayingOffline {
                                            soundView.pauseSong()
                                            isPlayingOffline = false
                                            isPlaying = false
                                        } else {
                                            soundView.continueSong()
                                            isPlayingOffline = true
                                            isPlaying = false
                                        }
                                    }
                                }
                                
                            }, label: {
                                if isPlaying || isPlayingOffline {
                                    if sound.musicUrl == savedURL {
                                        HStack {
                                            Text(sound.name).padding()
                                            Spacer()
                                        }.frame(width: width, height: height/13).background(Color.demalBlue).foregroundColor(.white).font(Font.headline.bold()).padding(.top, 10)
                                    } else {
                                        BackSoundContainer(backS: sound).padding(.top, 10)
                                    }
                                } else {
                                    BackSoundContainer(backS: sound).padding(.top, 10)
                                }
                            })
                        }
                    }
                }
                
            }
            
            if soundView.allSounds.isEmpty {
                Text(settings.kzLang ? "Жүктеу" :"Секунду").font(Font.headline.bold()).foregroundColor(.white)
            }
        }.onAppear(perform: {
            if soundView.allSounds.isEmpty {
                soundView.getSounds()
            }
        }).onReceive(soundView.$allSounds, perform: { _ in
            if soundView.allSounds.isEmpty {
                soundView.getSounds()
            }
        }).navigationBarTitle(Text(settings.kzLang ? "Дыбыстар" :"Фоновые звуки"), displayMode: .inline)
    }
}

struct BackSoundContainer: View {
    let backS: SoundStruct
    @ObservedObject var downloadModel = DownloadTaskModel()
    @EnvironmentObject var settings: UserInfo
    
    let width = UIScreen.main.bounds.width
    let height = UIScreen.main.bounds.height
    
    var body: some View {
        HStack {
            Text(backS.name).font(Font.headline).padding()
            Spacer()
            if !settings.checkExisting(urlString: backS.musicUrl) && !downloadModel.showDownloadProgress{
                Spacer()
                Button(action: {
                    downloadModel.startDownload(urlString: backS.musicUrl)
                }, label: {
                    Image(systemName: "arrow.down")
                }).padding()
            }
        }.frame(width: width, height: height/13).background(Color.demalBlue.opacity(0.4)).foregroundColor(.white)
    }
}
