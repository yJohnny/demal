//
//  BackSoundModel.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/22/20.
//

import SwiftUI
import FirebaseDatabase
import FirebaseAuth
import FirebaseStorage
import Combine
import AVFoundation

struct SoundStruct: Identifiable {
    var id = UUID()
    var backSoundId, musicUrl, name: String
}

class BackSoundModel: ObservableObject {
    @Published var allSounds = [SoundStruct]()
    private var ref = Database.database().reference()
    private var storRef = Storage.storage().reference()
    @Published var currentVolume: Float = 1.0
    var player: AVPlayer?
    var offlinePlayer: AVAudioPlayer?
    
    func playSong(url: String) {
        offlinePlayer = nil
        let playerItem = AVPlayerItem( url:NSURL( string: url )! as URL )
        player = AVPlayer(playerItem: playerItem)
        
        if let pl = player {
            pl.rate = 1.0
            pl.play()
        }
    }
    
    func continueSong() {
        if let pl = player {
            pl.play()
        }
        
        if let pl = offlinePlayer {
            pl.play()
        }
    }
    
    func pauseSong() {
        if let pl = player {
            pl.pause()
        }
        
        if let pl = offlinePlayer {
            pl.pause()
        }
    }
    
    func setVolume(vol: Float) {
        if let pl = player {
            pl.volume = vol
            currentVolume = vol
        }
        
        if let pl = offlinePlayer {
            pl.volume = vol
            currentVolume = vol
        }
    }
    
    func playFromDocuments(url: String) {
        player = nil
        let url = URL(string: url)
        
        guard url != nil else {
            return
        }
        do {
            offlinePlayer = try AVAudioPlayer(contentsOf: url!)
            offlinePlayer?.play()
        } catch {
            print("error")
        }
    }
    
    func getMusicPath(urlString: String) -> String{
        var str = ""
        if let ValidUrl = URL(string: urlString) {
            let directoryPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            str = (directoryPath.appendingPathComponent(ValidUrl.lastPathComponent)).path
        }
        return str
    }
    
    func getSounds() {
        var dataKeys = [Dictionary<String, Any>]()
            ref.child("BackSounds").observeSingleEvent(of: .value, with: { (snapshot) in
                
                if let data = snapshot.value as? NSDictionary {
                    dataKeys = (data.allValues as? [Dictionary<String, Any>])!
                }
                
                if self.allSounds.isEmpty {
                for data in dataKeys {
                    let soundId = data["backSoundId"] as? String ?? ""
                    let name = data["name"] as? String ?? ""
                    let url = data["musicUrl"] as? String ?? ""
                    
                    let sound = SoundStruct(backSoundId: soundId, musicUrl: url, name: name)
                    self.allSounds.append(sound)
                }
                }
                })
            { (error) in

                  print(error.localizedDescription)
              }
    }
    
}
