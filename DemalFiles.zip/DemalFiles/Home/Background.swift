//
//  Background.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/13/20.
//

import SwiftUI
import FirebaseStorage

struct Background: View {
    @ObservedObject var backView = BackgroundModel()
    @EnvironmentObject var settings: UserInfo
    @Binding var showBackground: Bool
    @State var showDownloadView = false
    @State var selectedImgUrl = ""
    
    @State var width = UIScreen.main.bounds.width
    @State var height = UIScreen.main.bounds.height
    
    var body: some View {
        ZStack {
            if settings.backgroundUrl == "background" {
                Image("background")
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            } else {
                Image(uiImage: UIImage(contentsOfFile: settings.getUrlPath(lastComponent: settings.backgroundUrl)) ?? UIImage())
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            }
            ScrollView(.vertical, showsIndicators: false) {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 20), count: 2), spacing: 20) {
                    ForEach(backView.allImages) { img in
                        VStack() {
                                BackgroundContainer(backS: img).onTapGesture {
                                    selectedImgUrl = img.imageUrl
                                    showDownloadView = true
                                }
                        }
                    }
                }
            }
            NavigationLink(destination: BackgroundDownloadView(showDownloadView: $showDownloadView, urlImage: $selectedImgUrl), isActive: self.$showDownloadView) {
                EmptyView()
            }
            if backView.allImages.isEmpty {
                Text(settings.kzLang ? "Жүктеу" :"Секунду").font(Font.headline.bold()).foregroundColor(.white)
            }
        }.onAppear(perform: {
            if backView.allImages.isEmpty {
                backView.getData()
            }
        }).onReceive(backView.$allImages, perform: { _ in
            if backView.allImages.isEmpty {
                backView.getData()
            }
        }).navigationBarTitle(Text(settings.kzLang ? "Сурет таңдау" :"Выбор Фона"), displayMode: .inline)
    }
}

struct BackgroundContainer: View {
    let backS: BackStruct
    let width = UIScreen.main.bounds.width
    let height = UIScreen.main.bounds.height
    @State private var animating = true
    
    var body: some View {
        ZStack() {
            if animating {
                ActivityIndicatorView(animating: $animating, style: .medium)
            }
            UrlImageView(urlString: backS.imageUrl).frame(width: width/2.3, height: height/2.5)
            VStack {
                Spacer()
                Text(backS.nameBack).frame(idealWidth: width/2.3, maxWidth: width/2.3, alignment: .center).padding(.horizontal).font(Font.headline.bold()).foregroundColor(Color.white)
            }
        }.frame(width: width/2.3, height: height/2.5).background(Color.gray).cornerRadius(15).onAppear(perform: {
            DispatchQueue.main.asyncAfter(deadline: .now() + 20.0) {
                animating = false
            }
        })
    }
}

struct BackgroundDownloadView: View {
    @ObservedObject var backView = BackgroundModel()
    @ObservedObject var downloadModel = DownloadTaskModel()
    @EnvironmentObject var settings: UserInfo
    @Binding var showDownloadView: Bool
    @Binding var urlImage: String
    
    let width = UIScreen.main.bounds.width
    let height = UIScreen.main.bounds.height
    
    var body: some View {
        ZStack {
            UrlImageView(urlString: urlImage)
            VStack() {
            if downloadModel.showDownloadProgress {
                Spacer()
                Text(settings.kzLang ? "Жүктеу" : "Идет загрузка..").font(Font.title.bold()).foregroundColor(.white)
                ProgressView(value: downloadModel.progress, total: 1)
                Spacer()
                Button(action: {
                    downloadModel.cancelTask()
                }, label: {
                    Text(settings.kzLang ? "Жүктеуді тоқтату" : "Отменить загрузку").frame(width: width/1.9, height: height/13.3).padding(.horizontal).background(Color.demalRed, alignment: .center).foregroundColor(.white).cornerRadius(20).minimumScaleFactor(0.5)
                }).padding()
            } else {
                Spacer()
                Button(action: {
                    downloadModel.startDownload(urlString: urlImage)
                }, label: {
                    if settings.checkExisting(urlString: urlImage) {
                        Text(settings.kzLang ? "Суретті қою" :"Установить").frame(width: width/1.9, height: height/13.3).padding(.horizontal).background(Color.demalBlue, alignment: .center).foregroundColor(.white).cornerRadius(20)
                    } else {
                        Text(settings.kzLang ? "Суретті қою" :"Загрузить и установить").frame(width: width/1.9, height: height/13.3).padding(.horizontal).background(Color.demalBlue, alignment: .center).foregroundColor(.white).cornerRadius(20).minimumScaleFactor(0.5)
                    }
                }).padding()
            }
            }
        }.alert(isPresented: $downloadModel.showAlert, content: {
            Alert(title: Text("Message"), message: Text(downloadModel.alertMsg), dismissButton: .destructive(Text("OK"), action: {
                downloadModel.showDownloadProgress = false
            }))
        }).onChange(of: downloadModel.pathImg, perform: { value in
            guard let ValidURL = URL(string: urlImage) else {
                return
            }
            if ValidURL.lastPathComponent == downloadModel.pathImg {
                settings.backgroundUrl = downloadModel.pathImg
                UserDefaults.standard.set(settings.backgroundUrl, forKey: "backgroundImg")
                NotificationCenter.default.post(name: NSNotification.Name("backgroundImg"), object: nil)
            }
        })
    }
}
