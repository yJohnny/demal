//
//  BackgroundModel.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/14/20.
//

import SwiftUI
import FirebaseDatabase
import FirebaseAuth
import FirebaseStorage
import Combine

struct BackStruct: Identifiable {
    var id = UUID()
    var nameBack, imageUrl, backgroundId: String
}

class BackgroundModel: ObservableObject {
    @Published var allImages = [BackStruct]()
    private var ref = Database.database().reference()
    private var storRef = Storage.storage().reference()
    
    func getData() {
        var dataKeys = [Dictionary<String, Any>]()
            ref.child("Backgrounds").observeSingleEvent(of: .value, with: { (snapshot) in
                
                if let data = snapshot.value as? NSDictionary {
                    dataKeys = (data.allValues as? [Dictionary<String, Any>])!
                }
                
                if self.allImages.isEmpty {
                for data in dataKeys {
                    let name = data["nameBack"] as? String ?? ""
                    let imageId = data["backgroundId"] as? String ?? ""
                    let url = data["imageUrl"] as? String ?? ""
                    
                    let img = BackStruct(nameBack: name, imageUrl: url, backgroundId: imageId)
                    self.allImages.append(img)
                }
                }
                })
            { (error) in

                  print(error.localizedDescription)
              }
        }
    
}
