//
//  HomeView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/13/20.
//

import SwiftUI

struct HomeView: View {
    @ObservedObject var homeView = HomeViewModel()
    @EnvironmentObject var settings: UserInfo
    @State var showBackground = false
    @State var showBackSound = false
    @State var width = UIScreen.main.bounds.width
    @State var height = UIScreen.main.bounds.height
    
    @ObservedObject var meditate = MeditateModel()
    @ObservedObject var musics = MusicModel()
    @ObservedObject var sleeps = SleepModel()
    @State var currentCategory = "-MZIzGDz9f5ZUrz46D7E"
    @Binding var isPlayed: Bool
    @Binding var showPlayer: Bool
    @Binding var selectedMeditate: MeditateStruct
    @Binding var favoritesContent: [String]
    
    var body: some View {
        ZStack {
            if settings.backgroundUrl == "background" {
                Image("background")
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            } else {
                Image(uiImage: UIImage(contentsOfFile: settings.getUrlPath(lastComponent: settings.backgroundUrl)) ?? UIImage())
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            }
            VStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack{
                        HStack {
                        Button(action: {
                            showBackground = true
                        }, label: {
                            Image(systemName: "photo.fill.on.rectangle.fill").resizable().foregroundColor(.white).frame(width: width/11, height: height/19).padding()
                        })
                            Spacer()
                            Button(action: {
                                showBackSound = true
                            }, label: {
                                Image(systemName: "music.note.list").resizable().foregroundColor(.white).frame(width: width/11, height: height/19).padding()
                            })
                        }
                        if !favoritesContent.isEmpty {
                            HStack {
                                Text(settings.kzLang ? "Таңдаулылар" :"Nзбранное").font(Font.largeTitle.bold()).foregroundColor(Color.white)
                                Spacer()
                            }
                            HStack() {
                                //ALL MEDITATES OF SELECTED CATEGORY
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack {
                                        ForEach(meditate.allMeditates) { medit in
                                            if favoritesContent.contains(medit.meditateId) {
                                                    Button(action: {
                                                        selectedMeditate = medit
                                                        withAnimation(.spring()) {
                                                            showPlayer = true
                                                            isPlayed = true
                                                            print(medit.listenCount)
                                                        }
                                                    }, label: {
                                                        MeditateContainer(meditate: medit)
                                                    })
                                            }
                                            }
                                        
                                        ForEach(musics.allMusics) { medit in
                                            if favoritesContent.contains(medit.meditateId) {
                                                    Button(action: {
                                                        selectedMeditate = medit
                                                        withAnimation(.spring()) {
                                                            showPlayer = true
                                                            isPlayed = true
                                                            print(medit.listenCount)
                                                        }
                                                    }, label: {
                                                        MeditateContainer(meditate: medit)
                                                    })
                                            }
                                            }
                                        
                                        ForEach(sleeps.allSleeps) { medit in
                                            if favoritesContent.contains(medit.meditateId) {
                                                    Button(action: {
                                                        selectedMeditate = medit
                                                        withAnimation(.spring()) {
                                                            showPlayer = true
                                                            isPlayed = true
                                                            print(medit.listenCount)
                                                        }
                                                    }, label: {
                                                        MeditateContainer(meditate: medit)
                                                    })
                                            }
                                            }
                                    }.padding(.bottom, isPlayed ? 80 : 0)
                                }
                                
                            }
                        }
                        
                        HStack {
                            Text(settings.kzLang ? "Жаңа туындылар" :"Новинки").font(Font.largeTitle.bold()).foregroundColor(Color.white)
                            Spacer()
                        }
                        HStack() {
                            //ALL MEDITATES OF SELECTED CATEGORY
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack {
                                    ForEach(meditate.allMeditates) { medit in
                                        if medit.listenCount < 5 {
                                                Button(action: {
                                                    selectedMeditate = medit
                                                    withAnimation(.spring()) {
                                                        showPlayer = true
                                                        isPlayed = true
                                                        print(medit.listenCount)
                                                    }
                                                }, label: {
                                                    MeditateContainer(meditate: medit)
                                                })
                                        }
                                        }
                                    ForEach(musics.allMusics) { medit in
                                        if medit.listenCount < 5 {
                                                Button(action: {
                                                    selectedMeditate = medit
                                                    withAnimation(.spring()) {
                                                        showPlayer = true
                                                        isPlayed = true
                                                        print(medit.listenCount)
                                                    }
                                                }, label: {
                                                    MeditateContainer(meditate: medit)
                                                })
                                        }
                                        }
                                    ForEach(sleeps.allSleeps) { medit in
                                        if medit.listenCount < 5 {
                                                Button(action: {
                                                    selectedMeditate = medit
                                                    withAnimation(.spring()) {
                                                        showPlayer = true
                                                        isPlayed = true
                                                        print(medit.listenCount)
                                                    }
                                                }, label: {
                                                    MeditateContainer(meditate: medit)
                                                })
                                        }
                                        }
                                }
                            }
                        }
                        
                        
                        NavigationLink(destination: Background(showBackground: $showBackground), isActive: self.$showBackground) {
                            EmptyView()
                        }
                        NavigationLink(destination: BackSound(showBackSound: $showBackSound), isActive: self.$showBackSound) {
                            EmptyView()
                        }
                    }
                }
            }
            
        }.navigationTitle("").navigationBarHidden(true).onAppear(perform: {
            if meditate.allMeditates.isEmpty {
                meditate.getMeditates()
            }
            if musics.allMusics.isEmpty {
                musics.getMusics()
            }
            if sleeps.allSleeps.isEmpty {
                sleeps.getSleeps()
            }
        })
    }
}
