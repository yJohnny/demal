//
//  HomeViewModel.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/13/20.
//

import SwiftUI
import FirebaseDatabase
import FirebaseAuth

class HomeViewModel: ObservableObject {

}
