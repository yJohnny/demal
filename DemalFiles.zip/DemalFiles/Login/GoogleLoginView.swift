//
//  GoogleLoginView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 6/5/21.
//

import SwiftUI
import GoogleSignIn
import Firebase

struct GoogleLoginView: UIViewRepresentable {
    
    func makeCoordinator() -> GoogleLoginView.Coordinator {
        return GoogleLoginView.Coordinator()
    }
    
    class Coordinator: NSObject, GIDSignInDelegate {
        private var ref = Database.database().reference()
        @Published var usersIds = [String]()
        
        func getIds(){
                var datas = NSDictionary()
                ref.child("Users").observeSingleEvent(of: .value, with: { (snapshot) in

                if let data = snapshot.value as? NSDictionary {
                    datas = data
                }
                for data in datas {
                    self.usersIds.append(data.key as? String ?? "")
                }
            })
                { (error) in
                    print(error.localizedDescription)
                }
        }
        
        func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error?) {
          if let error = error {
            print(error.localizedDescription)
            return
          }

          guard let authentication = user.authentication else { return }
          let credential = GoogleAuthProvider.credential(withIDToken: authentication.idToken,
                                                            accessToken: authentication.accessToken)
          Auth.auth().signIn(with: credential) { (authResult, error) in
            if let error = error {
              print(error.localizedDescription)
              return
            }
            self.getIds()
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                if !self.usersIds.contains(authResult!.user.uid) {
                    let userInfo = ["email": authResult!.user.email as Any, "id": authResult!.user.uid, "imageUrl": authResult!.user.photoURL?.absoluteString ?? "", "listenedCount": 0, "listenedMinutes": 0, "password": "password", "userName": authResult!.user.displayName as Any] as [String : Any]
                    self.ref.child("Users").child(authResult!.user.uid).setValue(userInfo)
                }
            }
            
            UserDefaults.standard.set(true, forKey: "status")
            NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
            UserDefaults.standard.set(authResult!.user.email!, forKey: "email")
            NotificationCenter.default.post(name: NSNotification.Name("email"), object: nil)
          }
        }
    }
    
    func makeUIView(context: UIViewRepresentableContext<GoogleLoginView>) -> GIDSignInButton {
        let view = GIDSignInButton()
        GIDSignIn.sharedInstance().delegate = context.coordinator
        GIDSignIn.sharedInstance()?.presentingViewController = UIApplication.shared.windows.last?.rootViewController
        return view
    }
    
    func updateUIView(_ uiView: GIDSignInButton, context: UIViewRepresentableContext<GoogleLoginView>) { }
}
