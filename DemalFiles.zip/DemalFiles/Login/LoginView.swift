//
//  LoginView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/3/20.
//

import SwiftUI
import GoogleSignIn
import Firebase

struct LoginView: View {
    @ObservedObject var loginModel = LoginViewModel()
    @EnvironmentObject var settings: UserInfo
    @State var email = ""
    @State var pass = ""
    @State var showSignUp = false
    @State var alertText: [String] = ["", ""]
    @State var showAlert = false
    @State var user = Auth.auth().currentUser
    @State var showSignInView = false
    @State var width = UIScreen.main.bounds.width
    @State var height = UIScreen.main.bounds.height
    
    var body: some View {
        NavigationView {
        ZStack{
            if settings.backgroundUrl == "background" {
                Image("background")
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            } else {
                Image(uiImage: UIImage(contentsOfFile: settings.getUrlPath(lastComponent: settings.backgroundUrl)) ?? UIImage())
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            }
            
            if showSignInView {
                VStack() {
                    HStack {
                        Button(action: {
                            showSignInView = false
                        }, label: {
                            Image(systemName: "arrow.backward").resizable().frame(width: width/11, height: height/19)
                        }).foregroundColor(.demalBlue)
                        Spacer()
                    }.padding(.horizontal)
                    Spacer()
                    Text(settings.kzLang ? "Қош келдіңіз" :"Добро пожаловать").font(Font.largeTitle.bold()).foregroundColor(.white)
                    Spacer()
                    
                    VStack(spacing: height/33) {
                        
                        Text(settings.kzLang ? "Кіру" :"Авторизация").font(.title).foregroundColor(.white)
                        TextField("эл. почта", text: $email).textFieldStyle(RoundedBorderTextFieldStyle()).frame(width: width/1.7).padding().foregroundColor(.black).autocapitalization(.none)
                        SecureField("пароль", text: $pass).textFieldStyle(RoundedBorderTextFieldStyle()).frame(width: width/1.7)
                        
                        Button(action: {
                            loginModel.logIn(email: self.email, password: self.pass) {
                                (verified) in
                                showSignInView = false
                                settings.status = verified
                                if verified {
                                    settings.email = email
                                    self.email = ""
                                    self.pass = ""
                                } else if self.email != "" && self.pass != "" {
                                    showAlert = true
                                    alertText[0] = settings.kzLang ? "Дұрыс емес пароль" :"Неверный логин или пароль"
                                    alertText[1] = settings.kzLang ? "Қайтадан" :"Попробовать еще"
                                } else {
                                    showAlert = true
                                    alertText[0] = settings.kzLang ? "Барлығын толтырыңыз" :"Заполните все поля"
                                    alertText[1] = settings.kzLang ? "Толтыру" :"Заполнить"
                                }
                            }
                        }, label: {
                            Text(settings.kzLang ? "Кіру" :"Войти").frame(width: width/1.9, height: height/13.3).padding(.horizontal).background(Color.demalBlue, alignment: .center).foregroundColor(.white).cornerRadius(20)
                        })
                        
                        .alert(isPresented: $showAlert) {
                                    Alert(title: Text(settings.kzLang ? "Қате" :"Ошибка"), message: Text(alertText[0]), dismissButton: .default(Text(alertText[1])))
                        }
                    }
                    Spacer()
                }
            }
            else {
                VStack() {
                    GoogleLoginView().frame(width: width/3.4, height: height/13.3).offset(x: -height/6.67)
                    Spacer()
                    Text("D E M A L").font(Font.largeTitle.bold()).foregroundColor(.white).italic().frame(width: 200, height: 100).border(Color.white, width: 3).minimumScaleFactor(0.5)
                    
                    Spacer()
                    
                    VStack(spacing: height / 66.7){
                        HStack {
                            Button(action: {
                                showSignUp = true
                            }, label: {
                                Text(settings.kzLang ? "Тіркелу" :"Регистрация").frame(width: width/3.4, height: height/13.3).padding(.horizontal).background(Color.demalBlue, alignment: .center).foregroundColor(.white).cornerRadius(20).minimumScaleFactor(0.5)
                            })
                            Spacer()
                            Button(action: {
                                showSignInView = true
                            }, label: {
                                Text(settings.kzLang ? "Кіру" :"Войти").frame(width: width/3.4, height: height/13.3).padding(.horizontal).background(Color.demalBlue, alignment: .center).foregroundColor(.white).cornerRadius(20).minimumScaleFactor(0.5)
                            })
                        }.padding(.horizontal)
                        
                        Button(action: {
                            settings.status = true
                        }, label: {Text(settings.kzLang ? "Кейін кіру" :"Пропустить")}).padding(.horizontal).foregroundColor(.white)
                        
                        NavigationLink(destination: SignUpView(showSingUp: $showSignUp), isActive: self.$showSignUp) {
                            EmptyView()
                        }

                        NavigationLink(destination: Main(), isActive: $settings.status) {
                                EmptyView()
                        }

                    }
                }
            }
            }
        }
        .navigationTitle("").navigationBarHidden(true)
        .onAppear {
            NotificationCenter.default.addObserver(forName: NSNotification.Name("email"), object: nil, queue: .main) { (_) in
                self.user = Auth.auth().currentUser
                self.settings.email = user?.email ?? ""
                self.settings.status.toggle()
            }
        }
    }
}

