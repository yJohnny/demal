//
//  LoginViewModel.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/3/20.
//

import SwiftUI
import FirebaseDatabase
import FirebaseAuth
import GoogleSignIn

class LoginViewModel: ObservableObject {

    func logIn(email: String, password: String, success: @escaping (Bool) -> Void) {
        if email != "" && password != "" {
            Auth.auth().signIn(withEmail: email, password: password) {
                (res, err) in
                if err != nil {
                    success(false)
                } else {
                    UserDefaults.standard.set(true, forKey: "status")
                    NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
                    UserDefaults.standard.set(email, forKey: "email")
                    NotificationCenter.default.post(name: NSNotification.Name("email"), object: nil)
                    success(true)
                }
            }
        } else {
            success(false)
        }
    }
}
