//
//  SignUpView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/3/20.
//

import SwiftUI

struct SignUpView: View {
    @ObservedObject var signUp = SignUpViewModel()
    @EnvironmentObject var settings: UserInfo
    @State var userName = ""
    @State var email = ""
    @State var pass = ""
    @Binding var showSingUp: Bool
    @State var showAlert = false
    @State var alertText: [String] = ["", ""]
    @State var width = UIScreen.main.bounds.width
    @State var height = UIScreen.main.bounds.height
    
    var body: some View {
        ZStack {
            if settings.backgroundUrl == "background" {
                Image("background")
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            } else {
                Image(uiImage: UIImage(contentsOfFile: settings.getUrlPath(lastComponent: settings.backgroundUrl)) ?? UIImage())
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            }
            VStack {
                HStack {
                    Button(action: {
                        showSingUp = false
                    }, label: {
                        Image(systemName: "arrow.backward").resizable().frame(width: width/11, height: height/19)
                    }).foregroundColor(.demalBlue)
                    Spacer()
                }.padding(.horizontal)
                
                Spacer()
                Text(settings.kzLang ? "Қош келдіңіз!" :"Добро пожаловать").font(Font.largeTitle.bold()).foregroundColor(.white)
                Spacer()
                
                VStack() {
                Text(settings.kzLang ? "Тіркелу" :"Регистрация").font(.title).foregroundColor(.white)
                TextField(settings.kzLang ? "аты-жөні" :"имя", text: $userName).textFieldStyle(RoundedBorderTextFieldStyle()).frame(width: width/1.7).padding().foregroundColor(.black).autocapitalization(.none)
                TextField("эл. почта", text: $email).textFieldStyle(RoundedBorderTextFieldStyle()).frame(width: width/1.7).padding().foregroundColor(.black).autocapitalization(.none)
                TextField("пароль", text: $pass).textFieldStyle(RoundedBorderTextFieldStyle()).frame(width: width/1.7).padding().foregroundColor(.black).autocapitalization(.none)
                
                Button(action: {
                    signUp.register(email: email, userName: userName, password: pass) {
                        (verified) in
                        showSingUp = verified ? false : true
                        if !verified {
                            if self.email != "" && self.pass != "" {
                                alertText[0] = settings.kzLang ? "Қате эл.почта" :"Такой эл. почты не существует"
                                alertText[1] = settings.kzLang ? "Қайтадан" :"Попробовать еще"
                                showAlert = true
                            } else {
                                alertText[0] = settings.kzLang ? "Барлығын толтырыңыз" :"Заполните все необходимые поля"
                                alertText[1] = settings.kzLang ? "Толтыру" :"Заполнить"
                                showAlert = true
                            }
                        }
                    }
                }, label: {
                    Text(settings.kzLang ? "Тіркелу" :"Зарегистрироваться").frame(width: width/1.9, height: height/13.3).padding(.horizontal).background(Color.demalBlue, alignment: .center).foregroundColor(.white).cornerRadius(20)
                })
                .alert(isPresented: $showAlert) {
                            Alert(title: Text(settings.kzLang ? "Қате" :"Ошибка"), message: Text(alertText[0]), dismissButton: .default(Text(alertText[1])))
                        }
                }
                Spacer()
            }
        }.navigationBarBackButtonHidden(true)
    }
}

