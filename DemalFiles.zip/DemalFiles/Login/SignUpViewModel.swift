//
//  SignUpViewModel.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/3/20.
//

import SwiftUI
import FirebaseDatabase
import FirebaseAuth

class SignUpViewModel: ObservableObject {
    var userInfo = [String: Any]()

    func register(email: String, userName: String, password: String, success: @escaping (Bool) -> Void) {
        let db = Database.database().reference().child("Users")
        
        if email != "" && password != "" {
            Auth.auth().createUser(withEmail: email, password: password) {
                (res, err) in
                if err != nil {
                    success(false)
                    return
                } else {
                    let userInfo = ["email": email, "id": Auth.auth().currentUser?.uid ?? "ID", "imageUrl": "", "listenedCount": 0, "listenedMinutes": 0, "password": password, "userName": userName] as [String : Any]
                    db.child(Auth.auth().currentUser?.uid ?? "ID").setValue(userInfo)
                    success(true)
                }
            }
        } else {
            success(false)
        }
    }
}
