//
//  Main.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/3/20.
//

import SwiftUI

struct Main: View {
    @ObservedObject var mainView = MainModel()
    @EnvironmentObject var settings: UserInfo
    @State var expand = false
    @State var selectedMeditate = MeditateStruct(audioUrl: "", description: "", imageUrl: "", name: "", meditateId: "", type: "", listenCount: 0, categoryId: [""])
    @State var isPlayed = false
    
    var body: some View {
        
        ZStack(alignment: Alignment(horizontal: .center, vertical: .bottom)) {
        TabView {
            HomeView(isPlayed: $isPlayed, showPlayer: $expand, selectedMeditate: $selectedMeditate, favoritesContent: $mainView.favorites)
                .tabItem({
                    Image(systemName: "house.fill")
                    Text(settings.kzLang ? "Басты" :"Главная")
                })
            SleepView(showPlayer: $expand, selectedSleep: $selectedMeditate, isPlayed: $isPlayed)
                .tabItem({
                    Image(systemName: "powersleep")
                    Text(settings.kzLang ? "Ертегі" :"Сон")
                })
            MeditateView(showPlayer: $expand, selectedMeditate: $selectedMeditate, isPlayed: $isPlayed)
                .tabItem({
                    Image(systemName: "face.smiling")
                    Text("Медитация")
                })
            MusicView(showPlayer: $expand, selectedMeditate: $selectedMeditate, isPlayed: $isPlayed)
                .tabItem({
                    Image(systemName: "music.note")
                    Text("Музыка")
                })
            MoreView(userInfo: $mainView.userInformation)
                .tabItem({
                    Image(systemName: "ellipsis")
                    Text(settings.kzLang ? "Қосымша" :"Дополнительно")
                })
        }
            
            PlayerView(showPlayer: $expand, meditateObj: $selectedMeditate, isPlayed: $isPlayed, favorites: $mainView.favorites, userInfo: $mainView.userInformation)
        
        }.navigationBarHidden(true).onAppear(perform: {
            print(settings.kzLang)
            if mainView.favorites.isEmpty {
                mainView.getFavorites()
            }
            if mainView.userInformation == nil{
                mainView.getUserInformation()
            }
        })
    }
}


struct MiniPlayer: View {
    var animation: Namespace.ID
    @Binding var expand: Bool
    @State var offset: CGFloat = 0
    
    var body: some View {
        VStack {
            HStack(spacing: 15) {
                Image(systemName: "rectangle.stack.fill")
                Spacer()
                Text("Music")
            }.padding(.horizontal)
        }.frame(maxHeight: expand ? .infinity : 80)
        .background(
            VStack(spacing: 0) {
                Color.orange
                Divider()
            }.onTapGesture(perform: {
                withAnimation(.spring()) {
                    expand = true
                }
            })
        ).ignoresSafeArea()
        .offset(y: expand ? 0 : -48)
        .offset(y: offset)
        .gesture(DragGesture().onEnded(onended(value:)).onChanged(onchanged(value: )))
    }
    
    func onended(value: DragGesture.Value) {
        if value.translation.height > 0 && expand {
            offset = value.translation.height
        }
    }
    func onchanged(value: DragGesture.Value) {
        withAnimation(.interactiveSpring(response: 0.5, dampingFraction: 0.95, blendDuration: 0.95)) {
            
            if value.translation.height > 300 {
                expand = false
            }
            offset = 0
        }
    }
}

    

