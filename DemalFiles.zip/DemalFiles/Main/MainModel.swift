//
//  MainModel.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/3/20.
//

import SwiftUI
import FirebaseDatabase
import FirebaseAuth

struct UserInformation: Identifiable {
    var id = UUID()
    var email, userId, imageUrl, password, userName: String
    var listenedCount, listenedMinutes: Int
}

class MainModel: ObservableObject {
    private var ref = Database.database().reference()
    public var favorites = [String]()
    public var userInformation: UserInformation?
    
    func getUserInformation() {
        if let user = Auth.auth().currentUser {
            print("FUNCTION CALLED----------------------------")
            ref.child("Users").child(user.uid).observeSingleEvent(of: .value, with: { (snapshot) in

                if let data = snapshot.value as? NSDictionary {
                    let email = data["email"] as? String ?? ""
                    let userId = data["id"] as? String ?? ""
                    let imageUrl = data["imageUrl"] as? String ?? ""
                    let password = data["password"] as? String ?? ""
                    let userName = data["userName"] as? String ?? ""
                    let listenedCount = data["listenedCount"] as? Int ?? 0
                    let listenedMinutes = data["listenedMinutes"] as? Int ?? 0
                    
                    let userInfo = UserInformation(email: email, userId: userId, imageUrl: imageUrl, password: password, userName: userName, listenedCount: listenedCount, listenedMinutes: listenedMinutes)
                    
                    self.userInformation = userInfo
                }
                
                print("USER INFORMATION IS \(self.userInformation)")
                })
            { (error) in

                  print(error.localizedDescription)
              }
        }
    }
    
    func getFavorites() {
        var getFavorites = NSDictionary()
        if let user = Auth.auth().currentUser {
            
            ref.child("Favorites").child(user.uid).observeSingleEvent(of: .value, with: { (snapshot) in

                if let data = snapshot.value as? NSDictionary {
                    getFavorites = data
                    print(getFavorites)
                }
                for data in getFavorites {
                    self.favorites.append(data.key as? String ?? "")
                    print(data.key)
                }
                })
        { (error) in

              print(error.localizedDescription)
          }
    }
    }
}
