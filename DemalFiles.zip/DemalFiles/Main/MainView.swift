//
//  MainView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/3/20.
//

import Foundation
