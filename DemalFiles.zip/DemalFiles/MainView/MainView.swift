//
//  MainView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 10/31/20.
//

import SwiftUI
import FirebaseDatabase

struct MainView: View {
    var body: some View {
        Text("WELCOME")
    }
}
