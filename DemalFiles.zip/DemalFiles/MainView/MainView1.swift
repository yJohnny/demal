//
//  ContentView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 10/29/20.
//

import SwiftUI
import FirebaseDatabase
import FirebaseAuth

struct MainView1: View {
    @EnvironmentObject var settings: UserInfo
    
    var body: some View {
        Text("Fuck you")
    }
}

