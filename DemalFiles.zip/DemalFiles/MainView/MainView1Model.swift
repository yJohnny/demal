//
//  MainView1Model.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/3/20.
//

import SwiftUI
import FirebaseDatabase
import FirebaseAuth

class MainView1Model: ObservableObject {
}
