//
//  MeditateView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/28/20.
//

import SwiftUI

struct MeditateView: View {
    @ObservedObject var meditate = MeditateModel()
    @State var currentCategory = "-MZIzGDz9f5ZUrz46D7E"
    let height = UIScreen.main.bounds.height
    @EnvironmentObject var settings: UserInfo
    @ObservedObject var mainView = MainModel()
    @Binding var showPlayer: Bool
    @Binding var selectedMeditate: MeditateStruct
    @Binding var isPlayed: Bool
    
    var body: some View {
        ZStack() {
            if settings.backgroundUrl == "background" {
                Image("background")
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            } else {
                Image(uiImage: UIImage(contentsOfFile: settings.getUrlPath(lastComponent: settings.backgroundUrl)) ?? UIImage())
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            }
            VStack() {
                
                // ALL CATEGORIES
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(self.meditate.meditateCategories) { category in
                            Button(action: {
                                    currentCategory = category.categoryId
                            }, label: {
                                if self.currentCategory == category.categoryId {
                                    Text(category.name).frame(width: 150, height: 50).background(Color.blue).cornerRadius(10).foregroundColor(.white).font(Font.body.bold()).overlay(
                                        RoundedRectangle(cornerRadius: 10)
                                            .stroke(Color.white, lineWidth: 3)
                                )
                                } else {
                                    Text(category.name).frame(width: 150, height: 50).background(Color.blue.opacity(0.6)).cornerRadius(10).foregroundColor(.gray)
                                }
                            })
                        }
                    }
                }.frame(height: height/11)
                Spacer()
                
                
                //ALL MEDITATES OF SELECTED CATEGORY
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 20), count: 2), spacing: 20) {
                        ForEach(meditate.allMeditates) { medit in
                                if medit.categoryId.contains(currentCategory) {
                                    Button(action: {
                                        selectedMeditate = medit
                                        withAnimation(.spring()) {
                                            showPlayer = true
                                            isPlayed = true
                                            print(medit.listenCount)
                                        }
                                    }, label: {
                                        MeditateContainer(meditate: medit)
                                    })
                                }
                            }
                        }
                    }.padding(.bottom, isPlayed ? 80 : 0)
                }
                
            }
            if meditate.allMeditates.isEmpty {
                Text(settings.kzLang ? "Жүктеу" :"Секунду").font(Font.headline.bold()).foregroundColor(.white)
            }
            
        }.onAppear(perform: {
            if meditate.allMeditates.isEmpty {
                meditate.getMeditates()
            }
        }).navigationTitle("").navigationBarHidden(true)
    }
}

struct MeditateContainer: View {
    let meditate: MeditateStruct
    let width = (UIScreen.main.bounds.width/2)-40
    @State private var animating = true
    
    var body: some View {
        ZStack() {
            if animating {
                ActivityIndicatorView(animating: $animating, style: .medium)
            }
            
            UrlImageView(urlString: meditate.imageUrl).frame(width: width, height: width * 2)
            VStack {
                Spacer()
                Text(meditate.name).frame(idealWidth: width, maxWidth: width, alignment: .center).padding([.leading, .trailing]).foregroundColor(Color.white).background(Color.blue.opacity(0.6)).cornerRadius(10)
            }
        }.frame(width: width, height: width * 2).background(Color.gray).cornerRadius(15).onAppear(perform: {
            DispatchQueue.main.asyncAfter(deadline: .now() + 20.0) {
                animating = false
            }
        })
    }
}
