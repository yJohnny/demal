//
//  PlayerModel.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 12/4/20.
//

import SwiftUI
import AVFoundation
import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth

class PlayerModel: ObservableObject {
    var player: AVPlayer?
    var offlinePlayer: AVAudioPlayer?
    @Published var isPlayed = false
    @Published var isPlaying = false
    @Published var currentVolume: Float = 1.0
    @Published var maxDuration: Float = 0.0
    @Published var currentTime: Float = 0.0
    private var ref = Database.database().reference()
    
    
    func playSong(url: String) {offlinePlayer = nil
        offlinePlayer = nil
        isPlayed = false
        isPlaying = false
        currentVolume = 1.0
        currentTime = 0.0
        maxDuration = 0.0
        
        let playerItem = AVPlayerItem( url:NSURL( string: url )! as URL )
        player = AVPlayer(playerItem: playerItem)
        maxDuration = Float(CMTimeGetSeconds((player?.currentItem?.asset.duration)!))
        
        if let pl = player {
            if maxDuration != 0.0 {
                pl.rate = 1.0
                pl.play()
                isPlayed = true
                isPlaying = true
            }
        }
    }
    
    func continueSong() {
        if let pl = player {
            if !isPlaying {
                pl.play()
                isPlaying = true
            }
        }
        
        if let pl = offlinePlayer {
            if !isPlaying {
                pl.play()
                isPlaying = true
            }
        }
    }
    
    func pauseSong() {
        if let pl = player {
            if isPlaying {
                pl.pause()
                isPlaying = false
            }
        }
        
        if let pl = offlinePlayer {
            if isPlaying {
                pl.pause()
                isPlaying = false
            }
        }
    }
    
    func setVolume(vol: Float) {
        if let pl = player {
            pl.volume = vol
            currentVolume = vol
        }
        if let pl = offlinePlayer {
            pl.volume = vol
            currentVolume = vol
        }
    }
    
    func updateTimer() {
        if let pl = player {
            currentTime = Float(CMTimeGetSeconds(pl.currentTime()))
        }
        if let pl = offlinePlayer {
            currentTime = Float(pl.currentTime)

        }
    }
    
    func seek(second: Float) {
        if maxDuration >= second && second >= 0 {
            if let pl = offlinePlayer {
                pl.currentTime = TimeInterval(second)
                if pl.rate == 0 {
                    pl.play()
                }
            }
        let targetTime: CMTime = CMTimeMake(value: Int64(second), timescale: 1)
        currentTime = second
        if let pl = player {
            pl.seek(to: targetTime)
                if pl.rate == 0
                {
                    pl.play()
                }
            }
        }
    }
    
    func exitPlayer() {
        offlinePlayer = nil
        player = nil
        isPlayed = false
        isPlaying = false
        currentVolume = 1.0
        currentTime = 0.0
        maxDuration = 0.0
    }
    
    func playFromDocuments(url: String) {
        player = nil
        isPlayed = false
        isPlaying = false
        currentVolume = 1.0
        currentTime = 0.0
        maxDuration = 0.0
        
        let url = URL(string: url)
        
        guard url != nil else {
            return
        }
        do {
            offlinePlayer = try AVAudioPlayer(contentsOf: url!)
            offlinePlayer?.play()
            maxDuration = Float(offlinePlayer?.duration ?? 0)
            
            if let pl = offlinePlayer {
                if maxDuration != 0.0 {
                    pl.rate = 1.0
                    pl.play()
                    isPlayed = true
                    isPlaying = true
                }
            }
        } catch {
            print("error")
        }
    }
    
    func getMusicPath(urlString: String) -> String {
        var str = ""
        if let ValidUrl = URL(string: urlString) {
            let directoryPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            str = (directoryPath.appendingPathComponent(ValidUrl.lastPathComponent)).path
        }
        return str
    }
    
    func addListenCount(content: MeditateStruct) {
        let db = Database.database().reference().child(content.type).child(content.meditateId).child("listenCount")
        db.setValue(content.listenCount + 1)
    }

    
    func addToFavorites(contentUrl: String) {
        if let user = Auth.auth().currentUser {
            let db = Database.database().reference().child("Favorites").child(user.uid).child(contentUrl)
            db.setValue(true)
        }
    }
    
    func deleteFromFavorites(contentUrl: String) {
        if let user = Auth.auth().currentUser {
            let db = Database.database().reference().child("Favorites").child(user.uid).child(contentUrl)
            db.removeValue()
            print("DELETE CALLED")
        }
    }
    
}
