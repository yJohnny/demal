//
//  PlayerView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 12/4/20.
//

import SwiftUI
import FirebaseAuth
import FirebaseDatabase

struct PlayerView: View {
    @EnvironmentObject var settings: UserInfo
    @ObservedObject var downloadModel = DownloadTaskModel()
    @Binding var showPlayer: Bool
    @Binding var meditateObj: MeditateStruct
    @Binding var isPlayed: Bool
    @ObservedObject var playModel = PlayerModel()
    let height = UIScreen.main.bounds.height
    let width = UIScreen.main.bounds.width
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    @State var offset: CGFloat = 0
    @State var frame: CGFloat = 80
    @State var showAlert = false
    @Binding var favorites: [String]
    @Binding var userInfo: UserInformation?
    @State var listenedSeconds = 1
    
    var body: some View {
        if isPlayed {
        ZStack {
            if showPlayer {
                UrlImageView(urlString: meditateObj.imageUrl).edgesIgnoringSafeArea(.all).brightness(-0.3).blur(radius: 10)
                if downloadModel.showDownloadProgress {
                    VStack {
                        ProgressView(settings.kzLang ? "Жүктеу" :"Загрузка", value: downloadModel.progress, total: 1)
                        Button(action: {
                            downloadModel.cancelTask()
                        }, label: {
                            Text("Cancel")
                        })
                    }
                } else {
                    VStack {
                    HStack {
                        Button(action: {
                            withAnimation(.spring()) {
                                showPlayer = false
                            }
                        }, label: {
                            Image(systemName: "chevron.down").foregroundColor(.white).font(.system(size: 25))
                        })
                        Spacer()
                        if !settings.checkExisting(urlString: meditateObj.audioUrl) {
                            Button(action: {
                                downloadModel.startDownload(urlString: meditateObj.audioUrl)
                            }, label: {
                                Image(systemName: "icloud.and.arrow.down").foregroundColor(.white).font(.system(size: 25))
                            })
                        }
                    }.padding(.all, 30)
                    Spacer()
                    UrlImageView(urlString: meditateObj.imageUrl).frame(width: 180, height: 180).cornerRadius(20)
                    Text(meditateObj.name).font(Font.headline.bold()).foregroundColor(.white).padding(.horizontal)
                    
                    Spacer()
                    VStack {
                    Spacer()
                    HStack() {
                    Spacer()
                        Button(action: {
                            playModel.seek(second: playModel.currentTime - 15)
                        }, label: {
                            Image(systemName: "gobackward.15").frame(width: 40, height: 40).foregroundColor(.white).font(.system(size: 25))
                        })
                    
                        Spacer()
                    Button(action: {
                        if !settings.checkExisting(urlString: meditateObj.audioUrl) {
                            if playModel.isPlaying {
                                playModel.pauseSong()
                            } else {
                                if playModel.isPlayed {
                                    playModel.continueSong()
                                } else {
                                    if let user = Auth.auth().currentUser {
                                        let db = Database.database().reference().child("Users").child(user.uid).child("listenedCount")
                                        if let listenedCount = userInfo?.listenedCount {
                                            db.setValue(listenedCount + 1)
                                            userInfo?.listenedCount = listenedCount + 1
                                        }
                                        print("TAPPED PLAY")
                                    }
                                    
                                    playModel.playSong(url: meditateObj.audioUrl)
                                }
                            }
                        } else {
                            if playModel.isPlaying {
                                playModel.pauseSong()
                            } else {
                                if playModel.isPlayed {
                                    playModel.continueSong()
                                } else {
                                    if let user = Auth.auth().currentUser {
                                        let db = Database.database().reference().child("Users").child(user.uid).child("listenedCount")
                                        if let listenedCount = userInfo?.listenedCount {
                                            db.setValue(listenedCount + 1)
                                            userInfo?.listenedCount = listenedCount + 1
                                        }
                                        print("TAPPED PLAY AGAIN")
                                    }
                                    
                                    playModel.playFromDocuments(url: playModel.getMusicPath(urlString: meditateObj.audioUrl))
                                }
                            }
                        }
                    }, label: {
                        Image(systemName: playModel.isPlaying ? "pause.fill" : "play.fill").frame(width: 50, height: 50).foregroundColor(.white).font(.system(size: 45))
                    })
                        Spacer()
                        
                        Button(action: {
                            playModel.seek(second: playModel.currentTime + 15)
                        }, label: {
                            Image(systemName: "goforward.15").frame(width: 40, height: 40).foregroundColor(.white).font(.system(size: 25))
                        })
                        Spacer()
                        Button(action: {
                            withAnimation(.spring()) {
                                showAlert = true
                                playModel.pauseSong()
                            }
                        }, label: {
                            Image(systemName: "stop.fill").frame(width: 40, height: 40).foregroundColor(.white).font(.system(size: 35))
                        }).alert(isPresented: $showAlert) {
                            Alert(title: Text(settings.kzLang ? "Ескерту" :"Предупреждение"), message: Text(settings.kzLang ? "Шығуды растайсызба?" :"Вы правда хотите закрыть Медитацию?"), primaryButton: .destructive(Text(settings.kzLang ? "Иа, шығу" :"Да, выйти").foregroundColor(.red), action: {
                                playModel.exitPlayer()
                                isPlayed = false
                                showPlayer = false
                            }), secondaryButton: .default(Text(settings.kzLang ? "Жоқ" :"Нет"), action: {
                                if playModel.isPlayed {
                                    playModel.continueSong()
                                } else {
                                    playModel.playSong(url: meditateObj.audioUrl)
                                }
                            }))
                            
                        }
                        Spacer()
                    }
                    Spacer()
                    Slider(value: Binding(get: {playModel.currentTime}, set: { newValue in
                            playModel.seek(second: newValue)
                    }), in: 0...playModel.maxDuration).frame(width: width-30)
                    HStack{
                        Text(Int(playModel.currentTime)%60 < 10 ? "\(Int(playModel.currentTime)/60):0\(Int(playModel.currentTime)%60)" : "\(Int(playModel.currentTime)/60):\(Int(playModel.currentTime)%60)").foregroundColor(.white).font(Font.body.bold()).padding(.horizontal)
                        Spacer()
                        Text(Int(playModel.maxDuration)%60 < 10 ? "\(Int(playModel.maxDuration)/60):0\(Int(playModel.maxDuration)%60)" : "\(Int(playModel.maxDuration)/60):\(Int(playModel.maxDuration)%60)").foregroundColor(.white).font(Font.body.bold()).padding(.horizontal)
                    }
                    Spacer()
                        Button(action: {
                            if favorites.contains(meditateObj.meditateId) {
                                playModel.deleteFromFavorites(contentUrl: meditateObj.meditateId)
                                favorites = favorites.filter(){ $0 != meditateObj.meditateId }
                                print(favorites)
                            } else {
                                playModel.addToFavorites(contentUrl: meditateObj.meditateId)
                                favorites.append(meditateObj.meditateId)
                                print(favorites)
                            }
                        }, label: {
                            if favorites.contains(meditateObj.meditateId) {
                                Image(systemName: "heart.fill").font(.system(size: 25)).foregroundColor(.red)
                            } else {
                                Image(systemName: "heart").font(.system(size: 25)).foregroundColor(.white)
                            }
                        })
                    Spacer()
                    HStack {
                        Image(systemName: playModel.currentVolume == 0 ? "speaker.slash.fill" : "speaker.wave.2.fill").resizable().frame(width: 20, height: 20).foregroundColor(playModel.currentVolume == 0 ? .red : .white)
                        Slider(value: Binding(get: {playModel.currentVolume}, set: { newValue in
                            playModel.setVolume(vol: newValue)
                        }), in: 0...1.0)
                        
                    }.padding(.horizontal)
                    Spacer()
                    }.edgesIgnoringSafeArea(.bottom).frame(height: 300, alignment: .center)
                }
                }
            } else {
                HStack() {
                    UrlImageView(urlString: meditateObj.imageUrl).frame(width: 80, height: 80).cornerRadius(20)
                    Text(meditateObj.name).foregroundColor(.white).padding(.horizontal)
                    Spacer()
                    Text(Int(playModel.currentTime)%60 < 10 ? "\(Int(playModel.currentTime)/60):0\(Int(playModel.currentTime)%60)" : "\(Int(playModel.currentTime)/60):\(Int(playModel.currentTime)%60)").foregroundColor(.white).font(Font.body.bold())
                    //PLAY - PAUSE BUTTON
                    Button(action: {
                        if playModel.isPlaying {
                            playModel.pauseSong()
                        } else {
                            if playModel.isPlayed {
                                playModel.continueSong()
                            } else {
                                playModel.playSong(url: meditateObj.audioUrl)
                            }
                        }
                    }, label: {
                        Image(systemName: playModel.isPlaying ? "pause.fill" : "play.fill").frame(width: 50, height: 50).foregroundColor(.white)
                    })
                }
            }
            
        }.onAppear(perform: {
            print(favorites)
            playModel.addListenCount(content: meditateObj)
        }).navigationTitle("").navigationBarHidden(true).onReceive(timer) {_ in
            if playModel.isPlaying {
                self.playModel.updateTimer()
                
                if listenedSeconds == 60 {
                    listenedSeconds = 0
                    
                    if let user = Auth.auth().currentUser {
                        let db = Database.database().reference().child("Users").child(user.uid).child("listenedMinutes")
                        if let listenedMinutes = userInfo?.listenedMinutes {
                            db.setValue(listenedMinutes + 1)
                            userInfo?.listenedMinutes = listenedMinutes + 1
                        }
                        print("TAPPED PLAY AGAIN")
                    }
                    print("MINUTE iS LEFT")
                }
                listenedSeconds += 1
                print(listenedSeconds)
            }
        }.frame(maxHeight: showPlayer ? .infinity : frame).background(
            VStack(spacing: 0) {
                if !showPlayer {
                    RoundedCorners(tl: 20, tr: 20, bl: 0, br: 0).fill(Color.black.opacity(0.8))
                    Divider()
                } else {
                    Color.black
                }
            }.onTapGesture(perform: {
                withAnimation(.spring()) {
                    showPlayer = true
                    offset = 0
                    frame = 80
                }
            })
        ).ignoresSafeArea()
        .offset(y: showPlayer ? 0 : -47)
        .offset(y: offset)
        .gesture(DragGesture().onEnded(onended(value:)).onChanged(onchanged(value: ))).onChange(of: meditateObj.audioUrl, perform: { value in
            if playModel.isPlayed {
                playModel.exitPlayer()
            }
        })
        } else {
            Text("Fix text").foregroundColor(Color.white.opacity(0)).navigationTitle("").navigationBarHidden(true)
        }
    }
    func onended(value: DragGesture.Value) {
        withAnimation(.interactiveSpring(response: 0.5, dampingFraction: 0.95, blendDuration: 0.95)) {
            if value.translation.height >= 200 && showPlayer {
                showPlayer = false
            } else if value.translation.height <= -200 && !showPlayer {
                showPlayer = true
            } else if frame >= 280 && !showPlayer {
                showPlayer = true
            }
            offset = 0
            frame = 80
        }
    }
    func onchanged(value: DragGesture.Value) {
        if value.translation.height > 0 && showPlayer {
            offset = value.translation.height
        } else if value.translation.height < 0 && !showPlayer {
            offset = value.translation.height
            frame = frame + offset * (-1)
        }
    }
    
}

struct RoundedCorners: Shape {
    var tl: CGFloat = 0.0
    var tr: CGFloat = 0.0
    var bl: CGFloat = 0.0
    var br: CGFloat = 0.0

    func path(in rect: CGRect) -> Path {
        var path = Path()

        let w = rect.size.width
        let h = rect.size.height

        // Make sure we do not exceed the size of the rectangle
        let tr = min(min(self.tr, h/2), w/2)
        let tl = min(min(self.tl, h/2), w/2)
        let bl = min(min(self.bl, h/2), w/2)
        let br = min(min(self.br, h/2), w/2)

        path.move(to: CGPoint(x: w / 2.0, y: 0))
        path.addLine(to: CGPoint(x: w - tr, y: 0))
        path.addArc(center: CGPoint(x: w - tr, y: tr), radius: tr,
                    startAngle: Angle(degrees: -90), endAngle: Angle(degrees: 0), clockwise: false)

        path.addLine(to: CGPoint(x: w, y: h - br))
        path.addArc(center: CGPoint(x: w - br, y: h - br), radius: br,
                    startAngle: Angle(degrees: 0), endAngle: Angle(degrees: 90), clockwise: false)

        path.addLine(to: CGPoint(x: bl, y: h))
        path.addArc(center: CGPoint(x: bl, y: h - bl), radius: bl,
                    startAngle: Angle(degrees: 90), endAngle: Angle(degrees: 180), clockwise: false)

        path.addLine(to: CGPoint(x: 0, y: tl))
        path.addArc(center: CGPoint(x: tl, y: tl), radius: tl,
                    startAngle: Angle(degrees: 180), endAngle: Angle(degrees: 270), clockwise: false)

        return path
    }
}
