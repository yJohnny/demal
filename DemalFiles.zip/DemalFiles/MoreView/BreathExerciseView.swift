//
//  BreathExerciseView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 5/30/21.
//

import SwiftUI

struct BreathExerciseView : View {
    @Binding var moveToExercise: Bool
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    @State var text = "Вдох"
    @State var time = 0
    @State var pulsate = false
    @State var start = false
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var settings: UserInfo
    @State var showExitButton = false
    
    var body : some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
                ZStack {
                        Circle()
                            .fill(Color.demalGreen)
                            .frame(width: 245, height: 245)
                            .scaleEffect(pulsate ? 1.4 : 1.0)
                            .animation(.linear(duration: 4))
                        Circle()
                            .fill(Color.demalBlue)
                            .frame(width: 200, height: 200)
                        if start {
                        Text(text).foregroundColor(.white).font(.title)
                        }
                        if !start {
                            Button(action: {
                                start = true
                                pulsate = true
                                showExitButton = false
                            }, label: {
                                Text(settings.kzLang ? "Бастау" :"Начать").foregroundColor(.white)
                            })
                    }
                }.onTapGesture {
                    if start {
                        withAnimation {
                            showExitButton.toggle()
                        }
                    } else {
                        start = true
                        pulsate = true
                        showExitButton = false
                    }
                }
            if showExitButton {
            VStack {
                Spacer()
                Button(action: {
                    moveToExercise = false
                    presentationMode.wrappedValue.dismiss()
                }, label: {
                    Text(settings.kzLang ? "Шығу" :"Выйти")
                        .padding().foregroundColor(.demalRed).font(Font.title.bold())
                }).padding()
            }
            }
        }.onTapGesture {
            withAnimation {
                showExitButton.toggle()
            }
        }.navigationTitle("").navigationBarHidden(true).onAppear(perform: {
            if settings.kzLang {
                text = "Дем ал"
            }
        }).onReceive(timer) { _ in
            if start {
            if time == 4 {
                self.text = settings.kzLang ? "Демді ұста" :"Задержите дыхание"
            } else if time == 6 {
                self.text = settings.kzLang ? "Демді шығар" :"Выдох"
                self.pulsate = false
            } else if time == 11 {
                self.text = settings.kzLang ? "Дем ал" :"Вдох"
                self.pulsate = true
                self.time = 0
            }
            self.time += 1
            }
        }
    }
}
