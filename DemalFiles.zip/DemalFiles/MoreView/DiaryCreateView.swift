//
//  DiaryCreateView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 6/9/21.
//

import SwiftUI
import FirebaseDatabase

struct DiaryCreateView: View {
    @Binding var moveToDiaryCreate: Bool
    @Binding var title: String
    @Binding var content: String
    @Binding var diaryId: String
    @Binding var gotSaved: Bool
    @EnvironmentObject var settings: UserInfo
    
    @ObservedObject var diaryModel = DiaryModel()
    let width = UIScreen.main.bounds.width
    let height = UIScreen.main.bounds.height
    
    var body: some View {
        ZStack {
            Color.demalBlue
                .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            VStack {
                TextField("Тема", text: $title).frame(width: width-50, height: 50).background(Color.white).padding()
                TextEditor(text: $content).frame(width: width-50, height: height/2).foregroundColor(content == "Пишите на листке.." ? .gray : .black).onTapGesture(perform: {
                    if content == "Пишите на листке.." {
                        content = ""
                    }
                })
                Spacer()
                Button(action: {
                    if diaryId != "" {
                        diaryModel.editDiary(diaryId: diaryId, title: title, content: content)

                    } else {
                        diaryModel.addDiary(title: title, content: content)
                    }
                    moveToDiaryCreate = false
                    gotSaved = true
                }, label: {
                        Text(settings.kzLang ? "Сақтау":"Сохранить")
                }).padding().font(Font.headline.bold()).foregroundColor(.black).background(Color.white).cornerRadius(7)
            }
        }
    }
}

