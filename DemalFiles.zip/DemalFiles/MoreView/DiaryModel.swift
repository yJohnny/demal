//
//  DiaryModel.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 6/9/21.
//

import SwiftUI
import FirebaseDatabase
import FirebaseAuth

struct DiaryStruct: Identifiable {
    var id = UUID()
    var content, diaryId, imageName, title, userId, addedDate: String
}

class DiaryModel: ObservableObject {
    let ref = Database.database().reference()
    @Published var allDiaries = [DiaryStruct]()
    
    func getDiaries() {
        if !allDiaries.isEmpty {
            allDiaries.removeAll()
        }
        if let user = Auth.auth().currentUser {
            var dataKeys = [Dictionary<String, Any>]()
            
            ref.child("Diaries").child(user.uid).observeSingleEvent(of: .value, with: { (snapshot) in
                var diariesArray = [DiaryStruct]()
                
                    if let data = snapshot.value as? NSDictionary {
                        dataKeys = (data.allValues as? [Dictionary<String, Any>])!
                    }

                    for data in dataKeys {
                        if let diaryTime = data["addedDate"] as? TimeInterval {
                            let content = data["content"] as? String ?? ""
                            let diaryId = data["id"] as? String ?? ""
                            let imageName = data["imageName"] as? String ?? ""
                            let title = data["title"] as? String ?? ""
                            let userId = data["userId"] as? String ?? ""
                            let date = Date(timeIntervalSince1970: diaryTime/1000)
                            let formatter = DateFormatter()
                            formatter.dateFormat = "dd/MM/yyyy"
                            let addedDate = formatter.string(from: date)
                            
                            let diary = DiaryStruct(content: content, diaryId: diaryId, imageName: imageName, title: title, userId: userId, addedDate: addedDate)
                            diariesArray.append(diary)
                        }
                    }
                self.allDiaries = diariesArray
                    
                    })
                { (error) in

                      print(error.localizedDescription)
                  }
        }
        
        
    }
    func addDiary(title: String, content: String) {
        print("called")
        
        if let user = Auth.auth().currentUser {
            let diaryId = UUID().uuidString
            let db = ref.child("Diaries").child(user.uid).child(diaryId)
            let diaryInfo = ["addedDate": ServerValue.timestamp(), "content": content, "id": diaryId, "imageName": "image", "title": title, "userId": user.uid] as [String : Any]
            db.setValue(diaryInfo)
        }
    }
    
    func editDiary(diaryId: String, title: String, content: String) {
        print("edit function called")
        if let user = Auth.auth().currentUser {
            let db = ref.child("Diaries").child(user.uid).child(diaryId)
            let diaryInfo = ["addedDate": ServerValue.timestamp(), "content": content, "id": diaryId, "imageName": "image", "title": title, "userId": user.uid] as [String : Any]
            db.setValue(diaryInfo)
            getDiaries()
        }
    }
}
