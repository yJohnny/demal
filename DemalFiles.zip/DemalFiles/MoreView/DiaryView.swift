//
//  DiaryView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 6/9/21.
//

import SwiftUI
import FirebaseDatabase

struct DiaryView: View {
    @Binding var moveToDiary: Bool
    @State var moveToDiaryCreate = false
    @Binding var userInfo: UserInformation?
    @State var title = ""
    @State var content = ""
    @State var selectedDiaryId = ""
    @State var gotSaved = false
    @ObservedObject var diaryModel = DiaryModel()
    @EnvironmentObject var settings: UserInfo
    
    let width = UIScreen.main.bounds.width
    let height = UIScreen.main.bounds.height
    
    var body: some View {
        ZStack {
            Color.demalBlue
                .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            
            ScrollView {
                VStack (){
                        ForEach(diaryModel.allDiaries) { diary in
                            Button(action: {
                                title = diary.title
                                content = diary.content
                                selectedDiaryId = diary.diaryId
                                moveToDiaryCreate.toggle()
                            }, label: {
                                HStack {
                                    VStack {
                                        Text(settings.kzLang ? "Тақырып: \(diary.title)" :"Тема: \(diary.title)").foregroundColor(.black).padding(.horizontal)
                                        Text(settings.kzLang ? "Мәтін: \(diary.content)" :"Текст: \(diary.content)").foregroundColor(.black).padding(.horizontal)
                                    }
                                    Spacer()
                                    Text(diary.addedDate).foregroundColor(.black).padding(.horizontal)
                                }.background(Color.white).cornerRadius(10)
                            }).frame(width: width-40, height: height/8).padding(.horizontal)
                        }
                    Spacer()
                    
                }
                
                NavigationLink(destination: DiaryCreateView(moveToDiaryCreate: $moveToDiaryCreate, title: $title, content: $content, diaryId: $selectedDiaryId, gotSaved: $gotSaved), isActive: $moveToDiaryCreate) {
                    EmptyView()
                }
            }
            
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button(action: {
                        selectedDiaryId = ""
                        title = ""
                        content = "Пишите на листке.."
                        moveToDiaryCreate.toggle()
                    }, label: {
                        Image(systemName: "plus.circle.fill").resizable().frame(width: 50, height: 50).foregroundColor(.demalRed).padding()
                    })
                }
            }
        }.navigationBarTitle(Text(settings.kzLang ? "Күнделік" :"Дневник"), displayMode: .inline).onAppear(perform: {
            if diaryModel.allDiaries.isEmpty {
                diaryModel.getDiaries()
                print("DIARY GOT")
            } else {
                if gotSaved {
                    print("Got saved works")
                    diaryModel.getDiaries()
                    gotSaved = false
                } else {
                    print("DIARY NOT GOT")
                }
            }
        }).onReceive(diaryModel.$allDiaries, perform: { _ in
            if diaryModel.allDiaries.isEmpty {
                diaryModel.getDiaries()
                print("ON RECEIVE WORKS")
            }
        })
    }
}
