//
//  MoreView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/2/20.
//

import SwiftUI
import Firebase

struct MoreView: View {
    @ObservedObject var moreV = MoreViewModel()
    @Environment (\.presentationMode) var presentationMode
    @EnvironmentObject var settings: UserInfo
    @State var moveToExercise = false
    @State var moveToDiary = false
    @Binding var userInfo: UserInformation?
    @State var moveToSettings = false
    
    let width = UIScreen.main.bounds.width
    let height = UIScreen.main.bounds.height
    
    var body: some View {
        ZStack {
            Color.demalBlue
                .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            if moveToSettings {
                SettingsView(userInfo: $userInfo, moveToSettings: $moveToSettings)
            } else {
                VStack() {
                    HStack {
                        if settings.email != "" {
                            if userInfo?.imageUrl == "" {
                                Image(systemName: "person.circle").resizable().frame(width: 50, height: 50)
                                    .clipShape(Circle())
                                Text("\(userInfo?.userName ?? "")").padding().font(Font.title.smallCaps()).foregroundColor(.white)
                            } else {
                                UrlImageView(urlString: userInfo?.imageUrl).frame(width: 50, height: 50)
                                .clipShape(Circle())
                                Text("\(userInfo?.userName ?? "")").padding().font(Font.title.smallCaps()).foregroundColor(.white)
                            }
                        } else {
                            VStack {
                                Text(settings.kzLang ? "Профильге кірілмеген" :"Вы не вошли в профиль").padding().font(Font.title.smallCaps()).foregroundColor(.white)
                                Button(settings.kzLang ? "Кіру/Тіркелу" :"Войти/Зарегистрироваться", action: {
                                    settings.status = false
                                }).padding(.horizontal).font(Font.headline.bold()).foregroundColor(.white).background(Color.blue).cornerRadius(7)
                            }
                        }
                        Spacer()
                        
                        Button(action: {
                            moveToSettings = true
                            print(moveToSettings)
                        }, label: {
                            Image(systemName: "gear").resizable().frame(width: 25, height: 25).foregroundColor(.white)
                        }).padding()
                    }
                    Spacer()
                    if settings.email != "" {
                        HStack(spacing: 10) {
                            VStack {
                                Image(systemName: "headphones").resizable().frame(width: 40, height: 40).padding(.top, 10)
                                Text(settings.kzLang ? "Тыңдалған аудио" :"Прослушали аудио: ").frame(width: (width-(width/10))/2, height: 80).lineLimit(2).minimumScaleFactor(0.5)
                                Text("\(userInfo?.listenedCount ?? 0)").font(Font.title.bold()).foregroundColor(.demalBlue).frame(width: (width-(width/10))/2, height: 40)
                            }.padding().frame(width: (width-(width/10))/2)
                            VStack {
                                Image(systemName: "timer").resizable().frame(width: 40, height: 40).padding(.top, 10)
                                
                                Text(settings.kzLang ? "Тыңдалған минут" :"Прослушали минут: ").frame(width: (width-(width/10))/2, height: 80).lineLimit(2).minimumScaleFactor(0.5)
                                
                                Text("\(userInfo?.listenedMinutes ?? 0)").font(Font.title.bold()).foregroundColor(.demalBlue).frame(width: (width-(width/10))/2, height: 40)
                            }.padding().frame(width: (width-(width/10))/2)
                        }.frame(width: width-(width/10), height: height/4).background(Color.white).cornerRadius(10)
                    }
                    Spacer()
                    
                    HStack {
                        if settings.email != "" {
                        Button(action: {
                            moveToDiary = true
                        }, label: {
                            VStack {
                                Image(systemName: "book.fill").resizable().frame(width: 50, height: 50).foregroundColor(Color.black)
                                Text(settings.kzLang ? "Күнделік" :"Дневник").foregroundColor(Color.black)
                            }
                        }).frame(width: 150, height: 150).background(Color.white)
                        }
                            Button(action: {
                                moveToExercise = true
                            }, label: {
                                VStack {
                                    Image(systemName: "lungs.fill").resizable().frame(width: 50, height: 50).foregroundColor(Color.black)
                                    Text(settings.kzLang ? "Демалу жаттығуы" :"Дыхательное упражнение").foregroundColor(Color.black)
                            }
                            }).frame(width: 150, height: 150).background(Color.white)
                    
                    }
                    
                    Spacer()
                }
            }
                
            NavigationLink(destination: BreathExerciseView(moveToExercise: $moveToExercise), isActive: $moveToExercise) {
                EmptyView()
            }
            NavigationLink(destination: DiaryView(moveToDiary: $moveToDiary, userInfo: $userInfo), isActive: $moveToDiary) {
                EmptyView()
            }
            
        }.navigationTitle("").navigationBarHidden(true)
    }
}
