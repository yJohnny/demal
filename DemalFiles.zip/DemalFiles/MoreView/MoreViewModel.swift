//
//  MoreViewModel.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/2/20.
//

import SwiftUI
import FirebaseDatabase
import FirebaseAuth
import GoogleSignIn

class MoreViewModel: ObservableObject {
    
    func logOut() {
        GIDSignIn.sharedInstance()?.signOut()
        try! Auth.auth().signOut()
        UserDefaults.standard.set(false, forKey: "status")
        NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
        UserDefaults.standard.set("", forKey: "email")
        NotificationCenter.default.post(name: NSNotification.Name("email"), object: nil)
    }
}
