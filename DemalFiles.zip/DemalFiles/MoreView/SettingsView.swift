//
//  SettingsView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 6/10/21.
//

import SwiftUI
import FirebaseDatabase
import FirebaseAuth

struct SettingsView: View {
    @EnvironmentObject var settings: UserInfo
    @ObservedObject var moreV = MoreViewModel()
    @Binding var userInfo: UserInformation?
    let ref = Database.database().reference()
    @State var kazLanguage = false
    @Binding var moveToSettings: Bool
    let languages = ["Қазақша", "Русский"]
    @State var selection = 0
    @State var changeProfile = false
    @State var changePassword = false
    
    @State var currentPassword = ""
    @State var newPassword = ""
    
    let width = UIScreen.main.bounds.width
    let height = UIScreen.main.bounds.height
    
    @State var showAlert = false
    @State var alertMsg = ""
    
    var body: some View {
        ZStack {
            Color.demalBlue
                .edgesIgnoringSafeArea(.all)
            if !changeProfile {
                VStack(spacing: 10) {
                    HStack {
                        Button(action: {
                            moveToSettings = false
                        }, label: {
                            Image(systemName: "arrow.backward").resizable().frame(width: width/11, height: height/19)
                        }).foregroundColor(.white)
                        Spacer()
                    }.padding(.horizontal)
                    
                    Spacer()
                    VStack {
                        Text(settings.kzLang ? "Тіл: \(languages[selection])" :"Язык: \(languages[selection])").foregroundColor(.white).font(.title)
                    Picker(selection: $selection, label: Text("Выберите язык")) {
                        ForEach(0..<languages.count) { index in
                            Text(self.languages[index]).tag(index)
                        }
                    }.pickerStyle(SegmentedPickerStyle())
                    }.padding()
                    
                    Spacer()
                    if settings.email != "" {
                        Button(settings.kzLang ? "Профильді өңдеу" :"Редактировать профиль", action: {
                            changeProfile = true
                        }).padding().font(Font.headline.bold()).foregroundColor(.black).background(Color.white).cornerRadius(7)
                        
                        Button(settings.kzLang ? "Парольді өзгерту" :"Изменить пароль", action: {
                            changeProfile = true
                            changePassword = true
                        }).padding().font(Font.headline.bold()).foregroundColor(.black).background(Color.white).cornerRadius(7)
                        
                        Button(settings.kzLang ? "Шығу" :"Выйти", action: {
                            moreV.logOut()
                            moveToSettings = false
                            settings.status = false
                            settings.email = ""
                        }).padding().font(Font.headline.bold()).foregroundColor(.white).background(Color.demalRed).cornerRadius(7)
                    }
                    Spacer()
                }
            }
            else {
                if changePassword {
                    VStack(spacing: 50) {
                        HStack {
                            Button(action: {
                                changePassword = false
                                changeProfile = false
                            }, label: {
                                Image(systemName: "arrow.backward").resizable().frame(width: width/11, height: height/19)
                            }).foregroundColor(.white)
                            Spacer()
                        }.padding(.horizontal)
                        
                        Spacer()
                        
                        Text(settings.kzLang ? "Парольді өзгерту" :"Смена пароля").font(Font.largeTitle.bold()).foregroundColor(Color.white)
                        TextField("старый пароль", text: $currentPassword).textFieldStyle(RoundedBorderTextFieldStyle()).frame(width: width/1.7).padding().foregroundColor(.black).autocapitalization(.none)
                        TextField("новый пароль", text: $newPassword).textFieldStyle(RoundedBorderTextFieldStyle()).frame(width: width/1.7).padding().foregroundColor(.black).autocapitalization(.none)
                        
                        Button(action: {
                            if currentPassword != newPassword {
                                if let user = Auth.auth().currentUser{
                                    if userInfo?.password == currentPassword && newPassword != "" {
                                        print("PASSWORD CHANGED!!!!!!!!!!!")
                                        user.updatePassword(to: newPassword) { (error) in
                                            print("CHANGING PASSWORD ERROR! \(error?.localizedDescription)")
                                        }
                                        alertMsg = "Вы успешно сменили пароль!"
                                        showAlert = true
                                        ref.child("Users").child(user.uid).child("password").setValue(newPassword)
                                    } else {
                                        alertMsg = "Неверный пароль!"
                                        showAlert = true
                                    }
                                }
                            } else {
                                alertMsg = "Неверный пароль!"
                                showAlert = true
                            }
                            currentPassword = ""
                            newPassword = ""
//                            changePassword = false
//                            changeProfile = false
                            
                        }, label: {
                            Text("Сменить пароль")
                        }).padding().font(Font.headline.bold()).foregroundColor(.black).background(Color.white).cornerRadius(7).alert(isPresented: $showAlert) {
                            Alert(title: Text("Сообщение"), message: Text(self.alertMsg), dismissButton: .default(Text("OK")))
                        }
                        Spacer()
                    }
                } else {
                    VStack(spacing: 50) {
                        Text("Профиль").font(Font.largeTitle.bold()).foregroundColor(Color.white)
                        
                        TextField("Имя", text: $currentPassword).textFieldStyle(RoundedBorderTextFieldStyle()).frame(width: width/1.7).padding().foregroundColor(.black).autocapitalization(.none)
                        TextField("Эл.почта", text: $newPassword).textFieldStyle(RoundedBorderTextFieldStyle()).frame(width: width/1.7).padding().foregroundColor(.black).autocapitalization(.none)
                        
                        Button(action: {
                            if currentPassword != userInfo?.userName && currentPassword != ""{
                                if let user = Auth.auth().currentUser {
                                    ref.child("Users").child(user.uid).child("userName").setValue(currentPassword)
                                    userInfo?.userName = currentPassword
                                    print("CALLED")
                                }
                            }
                            if newPassword != userInfo?.email && newPassword != "" {
                                if let user = Auth.auth().currentUser {
                                        print("EMAIL CHANGEDD!!!!!!!!!!!")
                                        user.updateEmail(to: newPassword) { (error) in
                                            print(error?.localizedDescription)
                                            print("ОШИБКА")
                                            ref.child("Users").child(user.uid).child("email").setValue(newPassword)
                                            userInfo?.email = newPassword
                                        }
                                }
                                print("CALLED")
                            }
                            changeProfile = false
                        }, label: {
                            Text("Сохранить изменения")
                        }).padding().font(Font.headline.bold()).foregroundColor(.black).background(Color.white).cornerRadius(7)
                        
                    }.onAppear(perform: {
                        currentPassword = userInfo?.userName ?? ""
                        newPassword = userInfo?.email ?? ""
                    })
//                    VStack {
//                        TextField("Старый email", text: $currentPassword)
//                        TextField("Новый email", text: $newPassword)
//
//                        Button(action: {
//
//
//
//                        }, label: {
//                            Text("Поменять email")
//                        })
//                    }
                }
            }
            
        }
        .navigationTitle("").navigationBarHidden(true).onAppear(perform: {
            if settings.kzLang {
                selection = 0
            } else {
                selection = 1
            }
        }).onChange(of: selection, perform: { value in
            if value == 0 && settings.kzLang != true {
                settings.kzLang = true
                UserDefaults.standard.set(true, forKey: "kzLang")
                NotificationCenter.default.post(name: NSNotification.Name("kzLang"), object: nil)
            }
            
            if value == 1 && settings.kzLang != false {
                settings.kzLang = false
                UserDefaults.standard.set(false, forKey: "kzLang")
                NotificationCenter.default.post(name: NSNotification.Name("kzLang"), object: nil)
            }
        })
    }
}



