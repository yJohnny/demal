//
//  MusicModel.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 5/10/21.
//

import SwiftUI
import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth

class MusicModel: ObservableObject {
    @Published var allMusics = [MeditateStruct]()
    @Published var musicCategories = [Categories]()
    private var ref = Database.database().reference()
    private var storRef = Storage.storage().reference()
    
    func getMusics() {
        var dataKeys = [Dictionary<String, Any>]()
        var categoriesGot = [Dictionary<String, Any>]()
        
            ref.child("Musics").observeSingleEvent(of: .value, with: { (snapshot) in

                if let data = snapshot.value as? NSDictionary {
                    dataKeys = (data.allValues as? [Dictionary<String, Any>])!
                }

                for data in dataKeys {
                    let audioUrl = data["audioUrl"] as? String ?? ""
                    let description = data["description"] as? String ?? ""
                    let name = data["name"] as? String ?? ""
                    let meditateId = data["id"] as? String ?? ""
                    let listenCount = data["listenCount"] as? Int ?? 0
                    let type = data["type"] as? String ?? ""
                    guard let categories = data["categoryId"] as? [String] else {
                        return
                    }

                    let imageUrl = data["imageUrl"] as? String ?? ""
                    
                    let music = MeditateStruct(audioUrl: audioUrl, description: description, imageUrl: imageUrl, name: name, meditateId: meditateId, type: type, listenCount: listenCount, categoryId: categories)
                    self.allMusics.append(music)
//                    imageUrl = imageUrl.components(separatedBy: "appspot.com/").last ?? ""
//                    self.storRef.child(imageUrl).downloadURL { dURL, error in
//                      if let error = error {
//                        print(error.localizedDescription)
//                      } else {
//                        imageUrl = dURL?.absoluteString ?? ""
//                        let music = MeditateStruct(audioUrl: audioUrl, description: description, imageUrl: imageUrl, name: name, meditateId: meditateId, categoryId: categories)
//                        self.allMusics.append(music)
//                      }
//                    }
                }
                
                })
            { (error) in

                  print(error.localizedDescription)
              }
        
        ref.child("Categories").child("Musics").observeSingleEvent(of: .value, with: { (snapshot) in

            if let data = snapshot.value as? NSDictionary {
                categoriesGot = (data.allValues as? [Dictionary<String, Any>])!
            }

            for data in categoriesGot {
                let categoryId = data["id"] as? String ?? ""
                let name = data["name"] as? String ?? ""
                
                let category = Categories(categoryId: categoryId, name: name)
                
                self.musicCategories.append(category)
            }
            
            })
        { (error) in

              print(error.localizedDescription)
          }
        
    }
}
