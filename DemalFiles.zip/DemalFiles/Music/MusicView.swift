//
//  MusicView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 5/10/21.
//

import SwiftUI

struct MusicView: View {
    @ObservedObject var meditate = MusicModel()
    @State var currentCategory = "-MZYuOWnXVnjBv83eMIu"
    let height = UIScreen.main.bounds.height
    @EnvironmentObject var settings: UserInfo
    @ObservedObject var mainView = MainModel()
    @Binding var showPlayer: Bool
    @Binding var selectedMeditate: MeditateStruct
    @Binding var isPlayed: Bool
    
    
    
    var body: some View {
        ZStack() {
            if settings.backgroundUrl == "background" {
                Image("background")
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            } else {
                Image(uiImage: UIImage(contentsOfFile: settings.getUrlPath(lastComponent: settings.backgroundUrl)) ?? UIImage())
                    .resizable()
                    .edgesIgnoringSafeArea(.all).blur(radius: 3, opaque: true)
            }
            VStack() {
                
                // ALL CATEGORIES
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(self.meditate.musicCategories) { category in
                            Button(action: {
                                    currentCategory = category.categoryId
                            }, label: {
                                if self.currentCategory == category.categoryId {
                                    Text(category.name).frame(width: 150, height: 50).background(Color.blue).cornerRadius(10).foregroundColor(.white).font(Font.body.bold()).overlay(
                                        RoundedRectangle(cornerRadius: 10)
                                            .stroke(Color.white, lineWidth: 3)
                                )
                                } else {
                                    Text(category.name).frame(width: 150, height: 50).background(Color.blue.opacity(0.6)).cornerRadius(10).foregroundColor(.gray)
                                }
                            })
                        }
                    }
                }.frame(height: height/11)
                Spacer()
                
                
                //ALL MEDITATES OF SELECTED CATEGORY
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 20), count: 2), spacing: 20) {
                        ForEach(meditate.allMusics) { medit in
                                if medit.categoryId.contains(currentCategory) {
                                    Button(action: {
                                        selectedMeditate = medit
                                        
                                        withAnimation(.spring()) {
                                            showPlayer = true
                                            isPlayed = true
                                        }
                                    }, label: {
                                        MeditateContainer(meditate: medit)
                                    })
                                }
                            }
                        }
                    }.padding(.bottom, isPlayed ? 80 : 0)
                }
                
            }
            if meditate.allMusics.isEmpty {
                Text(settings.kzLang ? "Жүктеу" :"Секунду").font(Font.headline.bold()).foregroundColor(.white)
            }
            
        }.onAppear(perform: {
            if meditate.allMusics.isEmpty {
                meditate.getMusics()
            }
        }).navigationTitle("").navigationBarHidden(true)
    }
}
