//
//  CustomColor.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 6/9/21.
//

import SwiftUI

extension Color {
    public static var demalBlue: Color {
        return Color(#colorLiteral(red: 0.2740572393, green: 0.5638074875, blue: 0.8772522211, alpha: 1))
    }
    
    public static var demalRed: Color {
        return Color(#colorLiteral(red: 0.8973056674, green: 0.3046323061, blue: 0.3769220114, alpha: 1))
    }
    
    public static var demalGreen: Color {
        return Color(#colorLiteral(red: 0.1571742063, green: 0.6948775569, blue: 0.661255602, alpha: 1))
    }
}
