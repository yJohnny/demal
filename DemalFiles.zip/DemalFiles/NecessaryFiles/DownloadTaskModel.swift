//
//  DownloadTaskModel.swift
//  DownloadTask
//
//  Created by Zhassulan Yegeubayev on 6/6/21.
//

import SwiftUI

class DownloadTaskModel: NSObject, ObservableObject, URLSessionDownloadDelegate {
    @Published var downloadURL: URL!
    @Published var alertMsg = ""
    @Published var showAlert = false
    @Published var showDownloadProgress = false
    @Published var progress: Float = 0
    @Published var pathImg = ""
    
    //SAVING DOWNLOAD task reference for cancelling...
    @Published var downloadTaskSession: URLSessionDownloadTask!
    
    //DOWNLOAD FUNCTION
    func startDownload(urlString: String) {
        
        //Checking for valid URL
        
        guard let ValidURL = URL(string: urlString) else {
            self.reportError(error: "INVALID URL!!!")
            return
        }
        
        let directoryPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        
        if FileManager.default.fileExists(atPath: directoryPath.appendingPathComponent(ValidURL.lastPathComponent).path) {
            print("yes, file found!")
            pathImg = ValidURL.lastPathComponent
            print("COPIED TO NOTIFICATION CENTER - \(pathImg)")
            
        } else {
            print("file not found, starting downloading!!!")
            showDownloadProgress.toggle()
            //VALID URL..
            //DOWNLOAD TASK..
            let session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
            downloadTaskSession = session.downloadTask(with: ValidURL)
            downloadTaskSession.resume()
        }
    }
    
    //REPORT ERROR FUNCTION
    func reportError(error: String) {
        alertMsg = error
        showAlert.toggle()
        print(error)
    }
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        //saving data
        
        guard let url = downloadTask.originalRequest?.url else {
            self.reportError(error: "Something went wrong!!!")
            return
        }
        
        //Directory path...
        let directoryPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        
        //creating one for storing File..
        //destination URL..
        //getting like ijustine.mp4...
        let destinationURL = directoryPath.appendingPathComponent(url.lastPathComponent)
        
        print("LAST COMPONENT OF URL \(url.lastPathComponent)")
        print("DESTINATION \(destinationURL)")
        
        //if already file is there removing that..
        try? FileManager.default.removeItem(at: destinationURL)
        
        do {
            try FileManager.default.copyItem(at: location, to: destinationURL)
            
            print("success")
            DispatchQueue.main.async {
                self.pathImg = url.lastPathComponent
                self.showDownloadProgress.toggle()
            }
        } catch {
            self.reportError(error: "PLEASE TRY AGAIN LATER!")
        }
    }
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        
        //getting progress
        DispatchQueue.main.async {
            self.progress = Float(CGFloat(totalBytesWritten) / CGFloat (totalBytesExpectedToWrite))
        }
        print(self.progress)
    }
    
    func cancelTask() {
        if let task = downloadTaskSession,task.state == .running {
            downloadTaskSession.cancel()
            withAnimation {
                self.showDownloadProgress = false
            }
            print("Canceled")
        }
    }
}

