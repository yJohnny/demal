//
//  UrlImageView.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 3/7/21.
//

import SwiftUI

struct UrlImageView: View {
    @ObservedObject var urlImageModel: UrlImageModel

    init(urlString: String?) {
        urlImageModel = UrlImageModel(urlString: urlString)
    }
    
    var body: some View {
            if let img = urlImageModel.image {
                Image(uiImage: img)
                    .resizable()
            }
    }
    
    static var defaultImage = UIImage(named: "background")
}
