//
//  UserInfo.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/6/20.
//

import SwiftUI

class UserInfo: ObservableObject {
    @Published var status = UserDefaults.standard.value(forKey: "status") as? Bool ?? false
    @Published var email = UserDefaults.standard.value(forKey: "email") as? String ?? ""
    @Published var backgroundUrl = UserDefaults.standard.value(forKey: "backgroundImg") as? String ?? "background"
    @Published var kzLang = UserDefaults.standard.value(forKey: "kzLang") as? Bool ?? false
    
    func getUrlPath(lastComponent: String) -> String {
        var str = "background"
        let directoryPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        str = (directoryPath.appendingPathComponent(lastComponent)).path
        return str
    }
    
    func checkExisting(urlString: String) -> Bool {
        var checker = false
        
        if let ValidURL = URL(string: urlString) {
            let directoryPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            
            if FileManager.default.fileExists(atPath: directoryPath.appendingPathComponent(ValidURL.lastPathComponent).path) {
                checker = true
            }
        }
        return checker
    }
}
