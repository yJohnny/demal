//
//  UserInto.swift
//  Demal
//
//  Created by Zhassulan Yegeubayev on 11/2/20.
//

import SwiftUI

class UserInto:
